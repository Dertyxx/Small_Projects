bgcolor ='#2CDF85'
fgcolor ='#18a832'
choices_color = '#d5f0d8'
choices_text_color = 'black'
button_start_color = '#d64b4b'
obj_color = '#1c331b'

